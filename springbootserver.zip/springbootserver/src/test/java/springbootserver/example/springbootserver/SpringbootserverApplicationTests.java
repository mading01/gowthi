package springbootserver.example.springbootserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootserverApplicationTests {

	@Test
	void contextLoads() {
	}

}

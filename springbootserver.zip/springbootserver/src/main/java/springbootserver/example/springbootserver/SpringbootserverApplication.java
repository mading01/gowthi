package springbootserver.example.springbootserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootserverApplication.class, args);
	}

}
